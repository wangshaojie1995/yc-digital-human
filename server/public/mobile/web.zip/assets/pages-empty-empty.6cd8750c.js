import{o as r,b as e}from"./index-dcb22eb8.js";import{_ as o}from"./_plugin-vue_export-helper.1b428a4d.js";const t=o({},[["render",function(o,t){return r(),e("div")}]]);export{t as default};
