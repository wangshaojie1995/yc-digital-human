const i="/mobile/static/images/icon/icon_visit.png";export{i as _};
